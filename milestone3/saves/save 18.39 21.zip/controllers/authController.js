const User = require("../models/User");
const Token = require("../models/Token");

var crypto = require('crypto');
var nodemailer = require('nodemailer');
const jwt = require('jsonwebtoken');


// handle errors
const handleErrors = (err) => {
  console.log(err.message, err.code);
  let errors = { email: '', password: '' };

  // incorrect email
  if (err.message === 'incorrect email') {
    errors.email = 'That email is not registered';
  }

  // incorrect password
  if (err.message === 'incorrect password') {
    errors.password = 'That password is incorrect';
  }

  // duplicate email error
  if (err.code === 11000) {
    errors.email = 'that email is already registered';
    return errors;
  }

  // validation errors
  if (err.message.includes('user validation failed')) {
    // console.log(err);
    Object.values(err.errors).forEach(({ properties }) => {
      // console.log(val);
      // console.log(properties);
      errors[properties.path] = properties.message;
    });
  }

  return errors;
}

// create json web token
const maxAge = 20 * 60;
const createToken = (id) => {
  return jwt.sign({ id }, 'secret', {
    expiresIn: maxAge
  });
};

// controller actions
module.exports.signup_get = (req, res) => {
  res.render('signup');
}

module.exports.restricted_get = (req, res) => {
  console.log("restricted call");
  res.render('restricted');
}

module.exports.login_get = (req, res) => {
  res.render('login');
}












module.exports.signup_post = async (req, res) => {
  const { email, password, role } = req.body;
  
  try 
  {
    const user = await User.create({ email, password, role });
    const token = createToken(user._id);
    console.log(user);

    try
    {
      const cnfrmToken = await Token.create({ _userId: user._id, token: crypto.randomBytes(16).toString('hex') });
      
      var transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
          user: 'watermonitor13@gmail.com',
          pass: 'e16388com'
        }
      });

      var mailOptions = { from: 'watermonitor13@gmail.com', 
      to: user.email, subject: 'Account Verification Token', 
      text: 'Hello,\n\n' + 'Please verify your account by clicking the link: \nhttp:\/\/' + req.headers.host + '\/confirmation\/' + cnfrmToken.token + '.\n' };

transporter.sendMail(mailOptions, function(error, info)
    {
    if (error) 
      {
        console.log(error);
      } 
    else 
      {
        console.log('Email sent: ' + info.response);
      }
    }); 

      res.cookie('jwt', token, { httpOnly: true, maxAge: maxAge * 1000 });
      res.status(201).json({ user: user });
    }
    catch(err) 
    { 
      console.log(err);
      res.status(400).json({ err });
    }    

  }
  catch(err) 
  {
    const errors = handleErrors(err);
    res.status(400).json({ errors });
  }
 
}




















module.exports.login_post = async (req, res) => {
  const { email, password } = req.body;

  try 
  {
    const user = await User.login(email, password);
    console.log(user);
    const token = createToken(user._id);
    res.cookie('jwt', token, { httpOnly: true, maxAge: maxAge * 1000 });
    res.status(200).json({ user: user });
   } 
  catch (err) 
  {
    const errors = handleErrors(err);
    res.status(400).json({ errors });
  }

}




















module.exports.logout_get = (req, res) => {
  res.cookie('jwt', '', { maxAge: 1 });
  res.redirect('/');
}



module.exports.confirmation_Post = async (req, res) => {
  console.log(req.params.id);
if(req.params.id)
{
  console.log(req.params.id);

  Token.findOne({ token: req.params.id }, function (err, token) {

    console.log(token);
    if (!token)
    {
     console.log("not verified");
     res.status(400).send({ msg: 'Token is not verified.' });
    }
    else
    { 
      console.log(" verified");
      console.log("expected id: "+ token._userId);

      User.findOne({ _id: token._userId}, function (err, user) {
        if (!user)  
          res.status(400).send({ msg: 'We were unable to find a user for this token.' });

        if (user.isVerified)  
          res.status(400).send({ type: 'already-verified', msg: 'This user has already been verified.' });

        else
        {
            // Verify and save the user
            user.isVerified = true;

            user.save(function (err) 
              {
                  if (err)
                  {  
                    res.status(500).send({ msg: "failed to confirm user" }); 
                  }
                  else
                  {
                    res.redirect('/');
                  }
            
              });

        }
        
        
    });
    }

   
}


);

}



}